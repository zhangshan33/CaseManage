create function f1(n1 int, n2 int)
  returns int
  BEGIN

DECLARE num INT ;  -- 也可以为声明的变量添加一个默认值DECLARE num INT DELETE 0 ;
SET num = n1 + n2 ; RETURN (num) ;
END;

