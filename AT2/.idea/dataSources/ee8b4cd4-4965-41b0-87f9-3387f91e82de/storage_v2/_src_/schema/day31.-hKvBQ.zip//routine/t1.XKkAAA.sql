create procedure t1()
  BEGIN
    SELECT * FROM t1;
END;

